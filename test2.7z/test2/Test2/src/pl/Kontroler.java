/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl;

import domen.Parnica;
import domen.Sudija;
import java.sql.SQLException;
import java.util.List;
import jdbc.DBBroker;

/**
 *
 * @author student1
 */
public class Kontroler {
    
    private static Kontroler instanca;
    
    private Kontroler() {
    }

    public static Kontroler getInstance() {
        if (instanca == null) {
            instanca = new Kontroler();
        }
        return instanca;
    }

    public List<Sudija> vratiListuSudija() throws SQLException {
        DBBroker.getInstance().poveziSe();
        return DBBroker.getInstance().vratiListuSudija();
    }

    public void sacuvajListuParnica(List<Parnica> listaParnica) throws SQLException {
        try {
            DBBroker.getInstance().poveziSe();
        } catch (SQLException ex) {
            throw ex;
        }
        try {
            DBBroker.getInstance().sacuvajListuParnica(listaParnica);
            DBBroker.getInstance().potvrdiTransakciju();
        } catch (SQLException ex) {
            DBBroker.getInstance().ponistiTransakciju();
            ex.printStackTrace();
            throw ex;
        }
    }

    public List<Parnica> vratiListuParnica() throws SQLException {
        DBBroker.getInstance().poveziSe();
        return DBBroker.getInstance().vratiListuParnica();
    }
    
    
    
}
