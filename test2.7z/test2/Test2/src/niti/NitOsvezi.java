/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package niti;

import domen.Parnica;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import pl.Kontroler;
import tm.ModelTabeleParnica;

/**
 *
 * @author neman
 */
public class NitOsvezi extends Thread {

    private JTable tblRegistrovaneParnice;

    public NitOsvezi(JTable tblRegistrovaneParnice) {
        this.tblRegistrovaneParnice = tblRegistrovaneParnice;
    }

    @Override
    public void run() {
        while (true) {
            try {
                List<Parnica> listaParnica = Kontroler.getInstance().vratiListuParnica();
                ModelTabeleParnica mtp = new ModelTabeleParnica(listaParnica);
                tblRegistrovaneParnice.setModel(mtp);
                Thread.sleep(10000);
            } catch (SQLException ex) {
                Logger.getLogger(NitOsvezi.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InterruptedException ex) {
                Logger.getLogger(NitOsvezi.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
