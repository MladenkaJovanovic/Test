/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import domen.Parnica;
import domen.Sudija;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author student1
 */
public class DBBroker {
    Connection konekcija;
    private static DBBroker instance;

    private DBBroker() {

    }

    public static DBBroker getInstance() {
        if (instance == null) {
            instance = new DBBroker();
        }
        return instance;
    }

    public void poveziSe() throws SQLException {

       konekcija = DriverManager.getConnection("jdbc:mysql://localhost:3306/prekvalifikacijatest", "root", "");
       konekcija.setAutoCommit(false);
    }

    public void potvrdiTransakciju() throws SQLException {
        konekcija.commit();
    }

    public void ponistiTransakciju() throws SQLException {
        konekcija.rollback();
    }

    public List<Sudija> vratiListuSudija() throws SQLException {
        
        List<Sudija> listaSudija = new ArrayList();

        String upit = "SELECT * FROM Sudija";

        Statement naredba = konekcija.createStatement();

        ResultSet rsSudija = naredba.executeQuery(upit);

        while (rsSudija.next()) {
            Sudija s = new Sudija();

            s.setSudijaID(rsSudija.getInt("SudijaID"));
            s.setIme(rsSudija.getString("Ime"));
            s.setPrezime(rsSudija.getString("Prezime"));
            s.setSpecijalnost(rsSudija.getString("Specijalnost"));
            listaSudija.add(s);
        }
        return listaSudija;
    }

    public void sacuvajListuParnica(List<Parnica> listaParnica) throws SQLException {
        String upit = "INSERT INTO Parnica(Naziv, Problem, DatumPocetka, Tuzilac, Tuzeni, SudijaID) VALUES (?,?,?,?,?,?)";
        PreparedStatement pripremljenaNaredba = konekcija.prepareStatement(upit);
        
        for (Parnica p : listaParnica) {
            
            pripremljenaNaredba.setString(1, p.getNaziv());
            pripremljenaNaredba.setString(2, p.getProblem());
            pripremljenaNaredba.setDate(3, new java.sql.Date(p.getDatumPocetka().getTime()));
            pripremljenaNaredba.setString(4, p.getTuzilac());
            pripremljenaNaredba.setString(5, p.getTuzeni());
            
            if(p.getSudija()!= null){
                pripremljenaNaredba.setInt(6, p.getSudija().getSudijaID());
            } else{
            pripremljenaNaredba.setNull(6, 0);
            }

            pripremljenaNaredba.executeUpdate();
        }
    }

    public List<Parnica> vratiListuParnica() throws SQLException {
        List<Parnica> listaParnica = new ArrayList<>();
        String upit = "SELECT * FROM parnica inner join sudija on parnica.SudijaID=sudija.SudijaID;";
        PreparedStatement pn = konekcija.prepareStatement(upit);
        ResultSet rs = pn.executeQuery();
        while (rs.next()) {
            Parnica p = new Parnica();
            p.setNaziv(rs.getString("Naziv"));
            p.setProblem(rs.getString("Problem"));
            p.setDatumPocetka(rs.getDate("DatumPocetka"));
            p.setTuzilac(rs.getString("Tuzilac"));
            p.setTuzeni(rs.getString("Tuzeni"));
            p.setSudija(new Sudija(rs.getInt("SudijaID"), rs.getString("Ime"), rs.getString("Prezime"), rs.getString("Specijalnost")));
            listaParnica.add(p);
        }
        return listaParnica;
    }


}
