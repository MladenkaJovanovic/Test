/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

/**
 *
 * @author student1
 */
public class Sudija {
    private int sudijaID;
    private String ime;
    private String prezime;
    private String specijalnost;

    public Sudija() {
    }

    public Sudija(int sudijaID, String ime, String prezime, String specijalnost) {
        this.sudijaID = sudijaID;
        this.ime = ime;
        this.prezime = prezime;
        this.specijalnost = specijalnost;
    }

    public int getSudijaID() {
        return sudijaID;
    }

    public void setSudijaID(int sudijaID) {
        this.sudijaID = sudijaID;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getSpecijalnost() {
        return specijalnost;
    }

    public void setSpecijalnost(String specijalnost) {
        this.specijalnost = specijalnost;
    }

    @Override
    public String toString() {
        return ime + " " + prezime +  " - " + specijalnost;
    }
    
    
}
