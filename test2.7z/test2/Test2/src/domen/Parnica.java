/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.util.Date;

/**
 *
 * @author student1
 */
public class Parnica {
    private int parnicaID;
    private String naziv;
    private String problem;
    Date datumPocetka;
    private String tuzilac;
    private String tuzeni;
    Sudija sudija;

    public Parnica() {
    }

    public Parnica(int parnicaID, String naziv, String problem, Date datumPocetka, String tuzilac, String tuzeni, Sudija sudija) {
        this.parnicaID = parnicaID;
        this.naziv = naziv;
        this.problem = problem;
        this.datumPocetka = datumPocetka;
        this.tuzilac = tuzilac;
        this.tuzeni = tuzeni;
        this.sudija = sudija;
    }

    public int getParnicaID() {
        return parnicaID;
    }

    public void setParnicaID(int parnicaID) {
        this.parnicaID = parnicaID;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getProblem() {
        return problem;
    }

    public void setProblem(String problem) {
        this.problem = problem;
    }

    public Date getDatumPocetka() {
        return datumPocetka;
    }

    public void setDatumPocetka(Date datumPocetka) {
        this.datumPocetka = datumPocetka;
    }

    public String getTuzilac() {
        return tuzilac;
    }

    public void setTuzilac(String tuzilac) {
        this.tuzilac = tuzilac;
    }

    public String getTuzeni() {
        return tuzeni;
    }

    public void setTuzeni(String tuzeni) {
        this.tuzeni = tuzeni;
    }

    public Sudija getSudija() {
        return sudija;
    }

    public void setSudija(Sudija sudija) {
        this.sudija = sudija;
    }
    
    
    
}
