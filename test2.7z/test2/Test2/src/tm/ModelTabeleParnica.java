/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tm;

import domen.Parnica;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author student1
 */
public class ModelTabeleParnica extends AbstractTableModel{
    
    private List<Parnica> listaParnica;
    private String[] nazivKolona = {"Naziv", "Problem", "Datum", "Tuzilac", "Tuzeni", "Sudija"};
    private DateFormat df = new SimpleDateFormat("dd.MM.yyyy");

    public ModelTabeleParnica() {
    }

    public ModelTabeleParnica(List<Parnica> listaParnica) {
        this.listaParnica = listaParnica;
    }

    @Override
    public int getRowCount() {
        return listaParnica.size();
    }

    @Override
    public int getColumnCount() {
        return nazivKolona.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        
        Parnica parnica = listaParnica.get(rowIndex);

        switch (columnIndex) {
            case 0:
                return parnica.getNaziv();
             
            case 1:
                return parnica.getProblem();
             
            case 2:
                return df.format(parnica.getDatumPocetka());
                
            case 3:
                return parnica.getTuzilac();
                
            case 4: 
                return parnica.getTuzeni();
                
            case 5:
                return parnica.getSudija().getIme() + " " + parnica.getSudija().getPrezime();
            default:
                return "n/a";
        }
    }
    
    public String getColumnName(int index) {
        return nazivKolona[index];
    }
    
    public List<Parnica> vratiParnicu() {
        return listaParnica;
    
    }
    
    public void dodajParnicu(Parnica parnica) {
        listaParnica.add(parnica);
        fireTableRowsInserted(listaParnica.size() - 1, listaParnica.size() - 1);
        
    }
    public Parnica vratiSelektovaniRed(int selektovaniRed) {
        return listaParnica.get(selektovaniRed);
    }
}
